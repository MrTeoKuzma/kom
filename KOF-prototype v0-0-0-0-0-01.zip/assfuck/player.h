#ifndef PLAYER_H_
#include "window.h"
#define PLAYER_H_
int pos;
class Player{
    private:
        int x;
        int y;
        int width;
        int height;
        int step;

    public:
        Player(){
            x = 0;
            y = 0;
            width = 128;
            height = 128;
            step = 5;
        }

        void draw(){
            //drawSquare(x, y, width, height, sf::Color::Blue);
            sf::Texture textureP;
            if(pos==1)
            textureP.loadFromFile("cU.png");
            else if(pos=4)
            textureP.loadFromFile("cD.png");
            else if(pos==3)
            textureP.loadFromFile("cL.png");
            else
            textureP.loadFromFile("cD.png");
            sf::Sprite player1(textureP);
            player1.setPosition(x, y);
            window.draw(player1);

        }

        void handleEvents(){
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
            {
                 x -= step;
                 pos=3;
            }


            if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
            {
                  x += step;
                  pos=2;
            }


            if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
            {
                y -= step;
                pos=1;
            }


            if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
            {
                y += step;
                pos=4;
            }

        }

};
Player player;
#endif
