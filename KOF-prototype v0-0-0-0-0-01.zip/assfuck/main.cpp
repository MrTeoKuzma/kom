#include <SFML/Graphics.hpp>
#include <string>
#include "player.h"
#include "event.h"
using namespace std;
int main()
{
    sf::Texture texture;
    sf::Texture texture1;
    if (!texture.loadFromFile("bg.png")){}
    sf::Sprite background(texture);
    if (!texture1.loadFromFile("fg.png")){}
    sf::Sprite fg(texture1);
    window.setFramerateLimit(60);
    while (window.isOpen())
    {
        handleEvents();
        window.clear();
        window.draw(background);
        player.draw();
        window.draw(fg);
        window.display();
    }
    return 0;
}
