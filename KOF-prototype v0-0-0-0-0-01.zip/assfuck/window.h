#ifndef WINDOW_H_
#define WINDOW_H_
sf::RenderWindow window(sf::VideoMode(1408,792), "*Insert title here*");
void drawSquare(int x, int y, int width, int height, sf::Color color){
    sf::RectangleShape rectangle(sf::Vector2f(width, height));
    rectangle.setPosition(x, y);
    rectangle.setFillColor(color);
    window.draw(rectangle);
}
#endif
