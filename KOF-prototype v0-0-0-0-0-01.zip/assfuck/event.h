#ifndef EVENT_H_
#define EVENT_H_
#include "player.h"
void handleEvents(){
    sf::Event event;
    while (window.pollEvent(event))
    {
        if (event.type == sf::Event::Closed)
            window.close();
    }
    player.handleEvents();
}
#endif
